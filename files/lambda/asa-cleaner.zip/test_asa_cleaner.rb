# frozen_string_literal: true

require_relative "lib/cleaner"

# Make sure to change the instance id
Cleaner.new("CHANGE_ME").run
